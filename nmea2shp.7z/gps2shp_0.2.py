import os, time, subprocess, arcpy

start_t = time.time()

logext = ".nmea"
javapath = "C:/Program Files/Java/jre7/bin/java.exe"
jarfile  = "RouteConverterCmdLine.jar"
logfolder   = os.getcwd() + "/log/"
shpfolder  = os.getcwd() + "/shp/"


logListAll = os.listdir(logfolder)
##logListAll = [
##'Stav-Eger_20141202.nmea',
##]

print("total GPS logs: " + str(len(logListAll)))

mergeList = []

for logfile in logListAll:
        
    currentlog = logfolder + logfile
    currentgpx = shpfolder + logfile.replace('-','_').replace(logext,'.gpx')
    currentshp = shpfolder + logfile.replace('-','_').replace(logext,'.shp')

    print(logfile)

    expression = '"' + logfile.replace('-','_').replace(logext,'') + '"'
    
    subprocess.call([javapath, '-jar', jarfile, currentlog, 'Gpx11Format', currentgpx])
    
    arcpy.GPXtoFeatures_conversion(currentgpx, currentshp)
    arcpy.CalculateField_management (currentshp, "Name", expression)

    mergeList.append(shpfolder + logfile.replace('-','_').replace(logext,".shp"))

print("merging logs points...")
arcpy.Merge_management(mergeList, shpfolder + "000_All_logs.shp")

print("creating lines...")
arcpy.PointsToLine_management(shpfolder + "000_All_logs.shp",shpfolder + "001_All_logs_lines.shp","Name")

end_t = time.time()
print('Completed computing in: ' + str(round(end_t-start_t, 2)) + 's')
